package util;

public final class Constant {	
	public static final String DATE_PATTERN = "MM/dd/yyyy";
}
