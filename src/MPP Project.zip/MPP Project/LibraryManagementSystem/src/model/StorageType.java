package model;

public enum StorageType {
	BOOKS, MEMBERS, USERS;
}
