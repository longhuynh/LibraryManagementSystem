1. Group members (see ppt file)
2. Functions: finish 100% all functions requirement. 
 + Login with user role.
 + See information user login in and logout.
 + Statistic books, members, staff and status of book at home page.
 + View books, add new book, search, copy book, checkout book, update book 
(double click and update), books was checkouted by member.
 + View members, member detail (by click a row on table or use UP/DOWN button on keyboard), 
add member and update member.
3. Non-function.
 + Beautiful layout and controls.
 + Customize TextField contronl with buttion clear on textfield and NumbericTextField
 + Easily to use.
 + Validation rule.
4. Class diagram and Sequence diagram: see ppt file.
NOTE: Run main method in class TestData (pakage dataaccess) to initialize data if you want. 
It also contain test data such as: user login
Run Main.java in pakage controller  file to login application